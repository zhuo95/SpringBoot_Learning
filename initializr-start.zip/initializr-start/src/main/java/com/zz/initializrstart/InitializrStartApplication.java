package com.zz.initializrstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InitializrStartApplication {

	public static void main(String[] args) {
		SpringApplication.run(InitializrStartApplication.class, args);
	}
}
